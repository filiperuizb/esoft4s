package br.com.boligon.filipe.utils;

public interface Tributavel {

    public double calcularImposto();

}
