public class Armazem {
    Double area;
    String tipo;

    public Armazem(Double area, String tipo) {
        this.area = area;
        this.tipo = tipo;
    }
}
