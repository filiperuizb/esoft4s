public class Elevador {
    Integer capacidade;
    String modelo;
    Predio predio;

    public Elevador(Integer capacidade, String modelo, Predio predio) {
        this.capacidade = capacidade;
        this.modelo = modelo;
        this.predio = predio;
    }
}
